Mapa interactivo con centros de ayuda ante violencia de género
![Mapa recursos genero](https://github.com/user-attachments/assets/f8ed3a4d-0eee-4e1a-be70-84cdf1743d86)
